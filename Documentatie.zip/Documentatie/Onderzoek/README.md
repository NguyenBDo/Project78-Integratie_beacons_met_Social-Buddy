Voeg alle onderzoeksdocumentatie hierin. Behalve Onderzoeksrapport (Engelstalig + individueel)

Bijv:
 - Literatuuronderzoek
 - Experimenteel onderzoek
 - Gebruikersonderzoek