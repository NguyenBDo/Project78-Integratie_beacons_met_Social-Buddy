Formuleer de files zoals dit: `fileName_SocialBudy78_20232024.extension` <br>
Files die niet in opleverset zitten: `X_fileName.extension` <br>